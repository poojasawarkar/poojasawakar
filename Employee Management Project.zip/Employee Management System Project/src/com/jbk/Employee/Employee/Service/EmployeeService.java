package com.jbk.Employee.Employee.Service;

import java.sql.SQLException;
import java.util.List;

import com.jbk.Employee.Employee.Dao.Employeedao;
import com.jbk.Employee.model.EmployeeModel;

public class EmployeeService {

	public void getData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		Employeedao dd=new Employeedao();
		dd.employeeInfo(obj);
	}
	
	public void UpdateData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		Employeedao dd=new Employeedao();
		dd.UpdateEmployee(obj);
	}
	public void deleteData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		Employeedao dd=new Employeedao();
		dd.deleteEmployee(obj);
	}
	public List<EmployeeModel> fetchData() throws ClassNotFoundException, SQLException
	{
		Employeedao dd=new Employeedao();
		List<EmployeeModel> list = dd.fetchEmployee();
		return list;
	}


}
