package com.jbk.Employee.Employee.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jbk.ConnectionFonfig.ConnectionDb;
import com.jbk.Employee.model.EmployeeModel;

public class Employeedao {

	public void employeeInfo(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		
		Connection con=null;
	    PreparedStatement ps=null;
		
		try {

			String query="insert into employee(name, salary,address) values(?,?,?)";
		    con = ConnectionDb.GetConnection();
		    ps = con.prepareStatement(query);
		    ps.setString(1, obj.getName());
		   ps.setDouble(2, obj.getSalary());
		   ps.setString(3, obj.getAddress());
		   int val = ps.executeUpdate();
		   System.out.println("Data Add Successfully.....");
		   System.out.println("**************************************************************************");
				
		} catch (Exception e) {
			
			System.out.println("Something Went Rong");	
		}finally {
			
			con.close();
			ps.close();
			
		}
	}   
	
	public void UpdateEmployee(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		Connection con=null;
	    PreparedStatement ps=null;
	
		try {
			String query="update employee set name=? where id=?";
		    con = ConnectionDb.GetConnection();
		    ps = con.prepareStatement(query);
		  
		 
		  ps.setString(1, obj.getName());
		  ps.setInt(2, obj.getId());
		 
		  int val = ps.executeUpdate();
		  System.out.println("Data UPDATE Successfully.....");
		  System.out.println("**************************************************************************");
					
		} catch (Exception e) {
			
			System.out.println("Something Went Rong");	
		}finally {
			
			con.close();
			ps.close();
			
		}
	}   
	
	public void deleteEmployee(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
		Connection con=null;
	    PreparedStatement ps=null;
	
		try {
			String query="delete from employee where id=?";
		    con = ConnectionDb.GetConnection();
		    ps = con.prepareStatement(query);
		  
		  ps.setInt(1, obj.getId());
		 
		  int val = ps.executeUpdate();
		  System.out.println("Data Deleted Successfully.....");
		  System.out.println("**************************************************************************");
				
		} catch (Exception e) {
			
			System.out.println("Something Went Rong");	
		}finally {
			
			con.close();
			ps.close();
			
		}
	}   
	
	public  List<EmployeeModel> fetchEmployee() throws ClassNotFoundException, SQLException
	{
		Connection con=null;
	    PreparedStatement ps=null;
	    
	    List<EmployeeModel> list=new ArrayList();
	    		
	    
		try {
			String query="Select * from employee";
		    con = ConnectionDb.GetConnection();
		    ps = con.prepareStatement(query);
		 
		   ResultSet rs = ps.executeQuery();
		   
		   while(rs.next())
		   {
			 int id =rs.getInt("id");
			  String name=rs.getString("name");
			  double salary=rs.getDouble("salary");
			   String address=rs.getString("address");
			   EmployeeModel e1=new EmployeeModel(id, name, salary, address);
			   
			   list.add(e1);
		   }
		   
			
		} catch (Exception e) {
			
			System.out.println("Something Went Rong");	
		}finally {
			
			con.close();
			ps.close();
			
		}
		return list;
	}  
	
}
