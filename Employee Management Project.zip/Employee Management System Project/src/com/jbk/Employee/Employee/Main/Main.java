package com.jbk.Employee.Employee.Main;


import java.sql.SQLException;
import java.util.List;

import com.jbk.Employee.Employee.Controller.EmployeeController;
import com.jbk.Employee.model.EmployeeModel;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	   EmployeeController ec=new EmployeeController();
	   EmployeeModel e1=new EmployeeModel(31,"Kiran Bhosale", 56000, "Pune");
	   
	   
	   ec.getData(e1);
	   ec.UpdateData(e1);
	   ec.deleteData(e1);
	   List<EmployeeModel> list = ec.fetchData();
	   System.out.println("---------------------------------Student Data---------------------------------");
	   for(EmployeeModel obj:list)
	   {
		   System.out.println(obj);
	   }
	   System.out.println(" ");
	   System.out.println("**************************************************************************");
	}
}
