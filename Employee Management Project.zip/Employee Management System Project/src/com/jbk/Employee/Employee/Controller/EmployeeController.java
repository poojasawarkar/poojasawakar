package com.jbk.Employee.Employee.Controller;

import java.sql.SQLException;
import java.util.List;

import com.jbk.Employee.Employee.Service.EmployeeService;
import com.jbk.Employee.model.EmployeeModel;

public class EmployeeController {

	public void getData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
	
		EmployeeService es=new EmployeeService();
		es.getData(obj);
	}
	public void UpdateData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
	
		EmployeeService ee=new EmployeeService();
		ee.UpdateData(obj);;
	}
	public void deleteData(EmployeeModel obj) throws ClassNotFoundException, SQLException
	{
	
		EmployeeService ee=new EmployeeService();
		ee.deleteData(obj);
	}
	
	public List<EmployeeModel> fetchData() throws ClassNotFoundException, SQLException
	{
		EmployeeService ee=new EmployeeService();
		 List<EmployeeModel> list = ee.fetchData();
		return list;
	}

}
